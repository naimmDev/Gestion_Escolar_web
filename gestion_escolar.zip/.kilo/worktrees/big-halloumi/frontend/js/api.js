const API_URL = 'http://localhost/gestion_escolar/api';

function getToken() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    return user?.token ?? null;
}

async function apiFetch(endpoint, options = {}) {
    const token = getToken();

    const headers = {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...(options.headers ?? {})
    };

    const response = await fetch(`${API_URL}${endpoint}`, { ...options, headers });

    if (response.status === 401) {
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
        return;
    }

    if (response.status === 403) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error ?? 'Acción no permitida');
    }

    return response;
}

/**
 * Hace fetch y devuelve directamente el array/objeto en data[].
 * Para GET que esperan una lista o un objeto de la API.
 */
async function apiGet(endpoint) {
    const res = await apiFetch(endpoint);
    if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? `Error ${res.status}`);
    }
    const json = await res.json();
    return json.data ?? json;
}